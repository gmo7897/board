<?php include("codefiles/login_code.php"); initialize(); ?>

<html>
	<head>
		<title><?php echo SITE_NAME; ?>: Login</title>
	</head>

	<body>
		<center><h1>Login Page</h1></center>
		<?php
			displayPage();
		?>
	</body>
</html>