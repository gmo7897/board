<?php include("codefiles/includes/SiteTools.inc"); deleteCookie(); ?>

<html>
	<head>
		<title><?php echo SITE_NAME; ?>: Logout</title>
	</head>

	<body>
		<center><h1>Logout Page</h1></center>
		You have successfully logged out.  Return <a href = "index.php">here</a>.
	</body>
</html>