<?php include("codefiles/includes/SiteConstants.inc"); ?>
<html>
	<head>
		<title><?php echo SITE_NAME; ?>: TOU</title>
	</head>
	
	<body>
		This mesage board has rules and regulations that must be followed.  You must agree to the following.<br>
<!--		<br />
		<ol>
			<li><b>Flaming:</b> (Insulting or ridiculing other users) Flaming of other users will not be tolerated on this message board.  If you don't like someone, you don't have to announce it to everyone.</li>
			<li><b>Trolling:</b> (Posts made to entice flames) Do not try to purposely anger people to cause them to flame you.  It is okay to have a difference of pinion, but announcing it in a way that will offend other people is just plain stupid.  It is just as bad as flaming.</li>
			<li><b>Disruptive Posting:</b> Disruptive posting is any type of posts that are made to disrupt conversations on the message boards.  This includes flooding (posting massive quantities of meaningless posts), spamming (meaningless or self-promoting posts), large blank posts, gibberish, and any other random stupidity that is obviously there just to be disruptive.  Disruptive posting will be dealt with <b>harsh</b> punishments.</li>
			<li><b>Illegal Activities:</b> It is okay to talk about illegal activities.  However, asking for/providing illegal goods or services is ground for suspension and even possible banning.</li>
			<li><b>Offensive Posting:</b> No nudity, pornography, excessive hate speech, don't make over half of the words in your post swear words, no pictures of graphic violence or mutilation or morbid mutation.  Breaking this rule will result in harsh penalties.</li>
		</ol><br /><br /><br />
		Overall, if you are an intelligent person and aren't just here to be a jerk, you will be fine on these message boards. -->
		<img src="dont-be-a-dick.jpg" alt="tou - don't be a dick" />
	</body>
</html>